# mockPIE
A REST API that implements an mock. It's usefull in testing the response of a communication with an API.
