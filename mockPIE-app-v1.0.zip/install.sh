#!/bin/bash
echo "Installing required dependencies for mockPIE, wait a moment..."
pip install -r requirements.txt

echo "Installation completed, enjoy!!!!"
